1)connect to your mysql database by using your login details 
2)after login run the create command file from commands folder using mysql editor
3) Once the script is executed a database named library will be created and the tables(Members,Staff,authentication,Publisher,books,Reports) will be created in the library database.